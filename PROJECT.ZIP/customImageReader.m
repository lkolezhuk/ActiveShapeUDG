function data = customImageReader(filename)
%     r = imread('C:\Users\Admin\Documents\Education\MAIA-Spain\CAD\PROJECT\Dataset\ref_histogram.png');
    temp = imread(filename);
    temp_resized = imresize(temp, [227 227]);
    
%     temp_resized = imhistmatch(temp_resized, r);
    temp_resized = adapthisteq(temp_resized);
    data(:,:,1) = temp_resized;
    data(:,:,2) = data(:,:,1);
    data(:,:,3) = data(:,:,1);
    
    
%     data = imresize(data, [227 227]);
end

