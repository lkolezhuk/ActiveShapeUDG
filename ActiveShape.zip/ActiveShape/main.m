close all;
clear all;
clc;

folder = 'hand/images/';
images_list = dir(strcat(folder,'*.jpg'));
shapes = dlmread('hand/shapes/shapes.txt');
shapes = shapes;
for i=1:size(images_list,1)
    images{i} = imread(strcat(folder,images_list(i).name));
end

figure; plot(shapes(1:56,:), shapes(57:end,:),'.');

mean_x = mean(mean(shapes(1:56,:)));
mean_y = mean(mean(shapes(57:end,:)));

difference = [mean(shapes(1:56,:)) - 0; mean(shapes(57:end,:)) - 0];

% normalized_shapes = [shapes(1:56,:) + difference(1,:)' shapes(57:end,:) + difference(2,:)']; 

for i=1:size(images,2)
    shapes(1:56,i) = shapes(1:56,i) - difference(1,i);
    shapes(57:end,i) = shapes(57:end,i) - difference(2,i);
    
end

mean_shape = shapes / (sqrt(sum(shapes.^2)));



figure; plot(mean_shape(1:56,:), mean_shape(57:end,:),'.-');





for image_i = 1 : size(shapes, 2)
    moving = [shapes(1:56,image_i); shapes(57:end,image_i)];
    fixed = [mean_shape(1:56); mean_shape(57:end)];

    a = (sum(moving.*fixed))/norm(moving);

    mmoving = [shapes(1:56,image_i) shapes(57:end,image_i)];
    mfixed = [mean_shape(1:56) mean_shape(57:end)];
    b = 0;
    b_sum = 0;

    for i=1:size(mean_shape,2)
        b_sum = b_sum + mmoving(i, 1) * mfixed(i, 2) - mmoving(i, 2) * mfixed(i, 1);
    end

    b = b_sum/(norm(moving))^2;


    scale_factor = sqrt(a^2 + b^2);
    rotation = atan(b/a);
    R = [cos(rotation) -sin(rotation); sin(rotation) cos(rotation)];

    for i=1:size(mmoving,1)
        mmoving(i,:) = R * mmoving(i,:)';
    end
    mmoving = scale_factor * mmoving;
    
    shapes(1:56,image_i) = mmoving(:,1);
    shapes(57:end,image_i) = mmoving(:,2);
end

mean_shape = shapes / (sqrt(sum(shapes.^2)));

figure; plot(shapes(1:56,:), shapes(57:end,:),'.');
title('Prealigned shapes');

% % % % % % % % % % PCA 

mean_of_data = mean(mean(shapes));
cov_of_data = cov(shapes);

