shapes.txt contains the subset of hands.
Note: shapes formatted as xxxyyy, each is 56 points i.e. 112 rows 
and one column per shape, 40 shapes.

Points are normalized w.r.t. to the height of the image.
I.e. to obtain pixel coordinates multiply x and y with 600.

Ordering w.r.t. to the images is alphanumeric.
